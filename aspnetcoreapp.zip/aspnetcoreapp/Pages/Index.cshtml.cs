using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace aspnetcoreapp.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
        }

        public void OnPost()
        {
            if (Request.Method.Equals("POST", StringComparison.OrdinalIgnoreCase))
            {
                double num1, num2;
                bool num1Valid = double.TryParse(Request.Form["num1"], out num1);
                bool num2Valid = double.TryParse(Request.Form["num2"], out num2);

                if (Request.Form["ADD"] == "ADD")
                {
                    if (num1Valid && num2Valid)
                    {
                        ViewData["summation"] = num1 + num2;
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for addition";
                    }
                }

                if (Request.Form["SQR"] == "SQR")
                {
                    if (num1Valid)
                    {
                        ViewData["summation"] = num1 * num1;
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for square";
                    }
                }

                if (Request.Form["POW"] == "POW")
                {
                    if (num1Valid && num2Valid)
                    {
                        ViewData["summation"] = Math.Pow(num1, num2);
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for power";
                    }
                }

                if (Request.Form["SUB"] == "SUB")
                {
                    if (num1Valid && num2Valid)
                    {
                        ViewData["summation"] = num1 - num2;
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for subtraction";
                    }
                }

                if (Request.Form["SIN"] == "SIN")
                {
                    if (num1Valid)
                    {
                        ViewData["summation"] = Math.Sin(num1);
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for sine";
                    }
                }

                if (Request.Form["COS"] == "COS")
                {
                    if (num1Valid)
                    {
                        ViewData["summation"] = Math.Cos(num1);
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for cosine";
                    }
                }

                if (Request.Form["TAN"] == "TAN")
                {
                    if (num1Valid)
                    {
                        ViewData["summation"] = Math.Tan(num1);
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for tangent";
                    }
                }

                if (Request.Form["RAD"] == "RAD")
                {
                    if (num1Valid)
                    {
                        ViewData["summation"] = Math.PI * num1 / 180.0;
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for radian conversion";
                    }
                }

                if (Request.Form["PI"] == "PI")
                {
                    ViewData["summation"] = Math.PI;
                }

                if (Request.Form["x"] == "x")
                {
                    if (num1Valid && num2Valid)
                    {
                        ViewData["summation"] = num1 * num2;
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for multiplication";
                    }
                }

                if (Request.Form["/"] == "/")
                {
                    if (num1Valid && num2Valid)
                    {
                        if (num2 != 0)
                        {
                            ViewData["summation"] = num1 / num2;
                        }
                        else
                        {
                            ViewData["summation"] = "Cannot divide by zero";
                        }
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for division";
                    }
                }

                if (Request.Form["CUBE"] == "CUBE")
                {
                    if (num1Valid)
                    {
                        ViewData["summation"] = num1 * num1 * num1;
                    }
                    else
                    {
                        ViewData["summation"] = "Invalid input for cube";
                    }
                }
            }
        }
    }
}
